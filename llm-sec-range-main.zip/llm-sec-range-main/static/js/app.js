// ============ 炫酷背景：矩阵雨 + 扫描线 ============
(function(){
  // 扫描线遮罩
  const scan = document.createElement('div');
  scan.className = 'scan';
  document.body.appendChild(scan);

  // 矩阵雨
  const cv = document.createElement('canvas');
  cv.id = 'matrix';
  document.body.appendChild(cv);
  const ctx = cv.getContext('2d');
  const chars = 'アカサタナハマヤラ0123456789ABCDEF<>{}[]#$%&LLMSEC';
  let cols, drops, fs = 14;
  function resize(){
    cv.width = innerWidth; cv.height = innerHeight;
    cols = Math.floor(cv.width / fs);
    drops = Array(cols).fill(0).map(()=>Math.random()*-100);
  }
  resize(); addEventListener('resize', resize);
  function draw(){
    ctx.fillStyle = 'rgba(5,7,13,0.10)';
    ctx.fillRect(0,0,cv.width,cv.height);
    ctx.font = fs + 'px monospace';
    for(let i=0;i<cols;i++){
      const c = chars[Math.floor(Math.random()*chars.length)];
      const x = i*fs, y = drops[i]*fs;
      ctx.fillStyle = Math.random()>0.97 ? '#22d3ee' : '#00ffae';
      ctx.fillText(c, x, y);
      if(y > cv.height && Math.random() > 0.975) drops[i] = 0;
      drops[i] += 0.6;
    }
    requestAnimationFrame(draw);
  }
  draw();
})();

// 右上角目标模型切换
document.addEventListener('DOMContentLoaded', ()=>{
  const sel = document.getElementById('model-select');
  if(!sel) return;
  sel.addEventListener('change', async ()=>{
    const r = await postJSON('/api/set-model', {model: sel.value});
    const lbl = sel.closest('.target-sel');
    if(lbl){ lbl.classList.add('flash'); setTimeout(()=>lbl.classList.remove('flash'), 600); }
    if(!r.ok) sel.value = r.current;
  });
});

// 点击「完整渗透语句」直接填入输入框
document.addEventListener('click', e=>{
  const p = e.target.closest('.payload');
  if(!p) return;
  const box = document.getElementById('msg');
  if(box){ box.value = p.dataset.fill || p.textContent; box.focus();
    box.dispatchEvent(new Event('input')); window.scrollTo({top:box.getBoundingClientRect().top+scrollY-200,behavior:'smooth'}); }
});

// 对话检查器：渲染每轮完整提交 messages + 模型原始返回
const ROLE_CN = {system:'system', user:'user', assistant:'assistant', note:'note'};
function appendInspector(debug){
  const box = document.getElementById('inspector');
  if(!box || !debug) return;
  const ph = box.querySelector('.insp-ph'); if(ph) ph.remove();
  const n = box.querySelectorAll('.insp-round').length + 1;
  const wrap = document.createElement('div'); wrap.className = 'insp-round';
  wrap.appendChild(elInsp('div','insp-rh','▸ ROUND '+n+' · 提交 messages（'+debug.sent.length+' 条）'));
  debug.sent.forEach(m=>{
    const b = document.createElement('div'); b.className = 'insp-msg insp-'+(m.role||'user');
    const tag = document.createElement('span'); tag.className='insp-role'; tag.textContent='['+(ROLE_CN[m.role]||m.role)+']';
    const c = document.createElement('span'); c.className='insp-c'; c.textContent = m.content;
    b.appendChild(tag); b.appendChild(c); wrap.appendChild(b);
  });
  wrap.appendChild(elInsp('div','insp-rh ret','◂ 模型原始返回'));
  wrap.appendChild(elInsp('div','insp-raw', debug.raw));
  box.appendChild(wrap); box.scrollTop = box.scrollHeight;
}
function elInsp(t,c,txt){ const e=document.createElement(t); e.className=c; e.textContent=txt; return e; }
function clearInspector(){
  const box=document.getElementById('inspector');
  if(box) box.innerHTML='<p class="spin insp-ph">发送后，这里显示每轮发给模型的完整 prompt 与原始返回</p>';
}

// 通用工具
async function postJSON(url, body){
  const r = await fetch(url, {method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify(body)});
  return r.json();
}
function el(tag, cls, text){
  const e = document.createElement(tag);
  if(cls) e.className = cls;
  if(text!=null) e.textContent = text;
  return e;
}
// 安全的轻量 Markdown：先转义 HTML 防 XSS，再渲染 **粗体** / `代码` / *斜体* / 换行
function mdSafe(s){
  const esc = String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  return esc
    .replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>')
    .replace(/`([^`]+)`/g,'<code>$1</code>')
    .replace(/(^|[^*])\*([^*\n]+)\*(?!\*)/g,'$1<em>$2</em>')
    .replace(/\n/g,'<br>');
}
function addMsg(box, cls, text){
  const m = el('div', 'msg '+cls);
  // 仅对模型回答(bot)渲染 Markdown；用户/拦截/系统提示保持纯文本
  if(/\bbot\b/.test(cls)) m.innerHTML = mdSafe(text);
  else m.textContent = text;
  box.appendChild(m);
  box.scrollTop = box.scrollHeight;
  return m;
}
